
#define FluxlPad_width 16
#define FluxlPad_heigth 8

