# OpenDrop Library [![Build Status](https://gaudi.ch/OpenDrop)

Arduino library for controlling OpenDrop V3 device
After downloading, rename folder to 'OpenDrop' and install in Arduino Libraries folder. Restart Arduino IDE, then open File->Sketchbook->Library->OpenDrop Text sketch.


